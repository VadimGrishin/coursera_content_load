def add_data_marts(conn, load_id):
    print('load_id: ', load_id)
    cursor = conn.cursor()
    cursor.callproc("data_mart.app0_ins", [load_id])
    print(cursor.fetchone()[0])
    #cursor.close()
